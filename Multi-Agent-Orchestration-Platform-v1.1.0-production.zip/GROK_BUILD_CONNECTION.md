# GROK BUILD CLIENT & EXTERNAL INTERFACE CONNECTION GUIDE

This document explains how to connect Grok Build UI or any compatible frontend client to the **DM Autonomous Orchestrator** backend.

---

## 1. Architecture Overview

```text
               GROK BUILD UI (Client)
                         |
           +-------------+-------------+
           |                           |
    REST API GATEWAY              MCP SERVER
(http://localhost:8000)      (http://localhost:8001)
           |                           |
           +-------------+-------------+
                         |
           DM AUTONOMOUS ORCHESTRATOR
                         |
  +----------------------+----------------------+
  |                      |                      |
Director             TaskDAG Engine         Memory/Storage
  |
  +--------+---------+----------+---------+
  |        |         |          |         |
Research Media   Browser    Computer  Facebook
  |
Ollama + Cloud APIs + MCP + GPU Cloud
```

---

## 2. Startup Instructions

Run the single startup command in PowerShell:

```powershell
.\start_platform.ps1
```

Or start the servers manually:

```powershell
# API Gateway (Port 8000)
.\.venv\Scripts\python.exe -m uvicorn src.api.server:app --port 8000

# MCP Server (Port 8001)
.\.venv\Scripts\python.exe -m uvicorn src.mcp.mcp_server:mcp_app --port 8001
```

---

## 3. Connection Endpoints

| Protocol | Service | Endpoint URL | Description |
| :--- | :--- | :--- | :--- |
| **REST API** | API Gateway | `http://localhost:8000` | REST API for agents, health, and workflow execution |
| **MCP** | MCP Server | `http://localhost:8001` | Model Context Protocol JSON-RPC tool server |
| **Ollama** | Local LLM | `http://localhost:11434` | Local model inference provider |

---

## 4. API & MCP Examples

### A. Health Check (REST API)
```bash
curl -X GET http://localhost:8000/health
```
**Response:**
```json
{
  "status": "ONLINE",
  "version": "v1.0.0-production"
}
```

### B. Execute Agent Task (REST API)
```bash
curl -X POST http://localhost:8000/agent/run \
  -H "Content-Type: application/json" \
  -H "X-API-Key: dm-secret-key-v1" \
  -d '{
    "agent": "research",
    "task": "Quantum Computing Trends 2026"
  }'
```

### C. List MCP Tools (MCP Server)
```bash
curl -X GET http://localhost:8001/mcp/tools
```

### D. Execute Tool via MCP (`run_workflow`)
```bash
curl -X POST http://localhost:8001/mcp/call \
  -H "Content-Type: application/json" \
  -d '{
    "tool": "run_workflow",
    "arguments": {
      "goal": "Build Facebook campaign for Autonomous AI"
    }
  }'
```

---

## 5. Security & Authentication
- API Key header: `X-API-Key: dm-secret-key-v1`
- Configuration file: `config/security.json`
