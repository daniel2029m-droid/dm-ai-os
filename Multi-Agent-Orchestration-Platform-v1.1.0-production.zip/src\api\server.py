import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .routes import router

app = FastAPI(
    title="DM Autonomous Orchestrator API Gateway",
    version="v1.0.0-production",
    description="REST API Gateway connecting Grok Build UI and external clients to DM Autonomous Multi-Agent Orchestrator"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(router)

def start_api(host: str = "0.0.0.0", port: int = 8000):
    uvicorn.run("src.api.server:app", host=host, port=port, reload=False, log_level="info")

if __name__ == "__main__":
    start_api()
