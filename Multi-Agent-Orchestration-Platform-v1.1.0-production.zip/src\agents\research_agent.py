"""
ResearchAgent - Information Gathering & Technical Research (Phase 2 Priority #3).
Uses CacheLayer to eliminate duplicate search/LLM calls, StorageLayer for records,
and CapabilityModelSelector for summarization.
"""

import asyncio
import logging
from typing import Dict, Any, List

from ..core.plugin_manager import BasePlugin, plugin_manager
from ..storage.storage_layer import storage
from ..providers.capability_selector import capability_selector

log = logging.getLogger("research_agent")

class ResearchAgent(BasePlugin):
    @property
    def plugin_name(self) -> str:
        return "research"

    @property
    def description(self) -> str:
        return "Technical research, document analysis, and topic summarization agent."

    async def initialize(self) -> bool:
        log.info("[ResearchAgent] Initialized.")
        return True

    async def conduct_research(self, topic: str) -> Dict[str, Any]:
        """Perform research on a topic, utilizing SHA-256 CacheLayer to avoid duplicate work."""
        cache_key = f"research_{topic.lower()}"
        cached = storage.get_cache("research", cache_key)
        
        if cached:
            log.info(f"[ResearchAgent] Cache HIT for topic '{topic}'")
            return {"status": "success", "source": "cache", "report": cached}

        log.info(f"[ResearchAgent] Generating research report for '{topic}'...")
        
        system_prompt = "You are a Senior Technical Researcher. Provide a concise, bulleted research report."
        report = capability_selector.generate(
            prompt=f"Research Topic: {topic}. Provide key findings, technical considerations, and recommendations.",
            capability="summarization",
            system_prompt=system_prompt
        )

        storage.set_cache("research", cache_key, report)
        storage.save_record("research_report", topic[:40], report)

        return {"status": "success", "source": "llm", "report": report}

    async def execute_action(self, action_name: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        if action_name == "research":
            topic = payload.get("topic", "General AI")
            return await self.conduct_research(topic)
        
        return {"status": "error", "message": f"Unknown action '{action_name}'."}

# Register plugin
research_agent_instance = ResearchAgent()
plugin_manager.register_plugin(research_agent_instance)
