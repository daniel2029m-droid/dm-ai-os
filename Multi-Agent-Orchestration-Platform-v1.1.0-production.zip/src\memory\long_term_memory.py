import sqlite3
import json
import os
import logging
from pathlib import Path
from typing import List, Dict, Any, Optional

log = logging.getLogger("long_term_memory")

class LongTermMemory:
    def __init__(self, db_path: Optional[str] = None):
        if not db_path:
            db_dir = Path(os.path.expanduser("~")) / ".gemini" / "antigravity-ide" / "scratch" / "Project_State" / "Memory"
            db_dir.mkdir(parents=True, exist_ok=True)
            db_path = str(db_dir / "memory.db")
            
        self.db_path = db_path
        self._init_db()

    def _init_db(self):
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS memories (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    content TEXT NOT NULL,
                    category TEXT DEFAULT 'general',
                    importance REAL DEFAULT 1.0,
                    embedding_json TEXT,
                    metadata_json TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            conn.commit()

    def store(self, content: str, category: str = "general", importance: float = 1.0, embedding: Optional[List[float]] = None, metadata: Optional[Dict[str, Any]] = None) -> int:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO memories (content, category, importance, embedding_json, metadata_json)
                VALUES (?, ?, ?, ?, ?)
            """, (
                content,
                category,
                importance,
                json.dumps(embedding or []),
                json.dumps(metadata or {})
            ))
            conn.commit()
            return cursor.lastrowid

    def get_all(self, category: Optional[str] = None) -> List[Dict[str, Any]]:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            if category:
                cursor.execute("SELECT id, content, category, importance, embedding_json, metadata_json, created_at FROM memories WHERE category = ? ORDER BY id DESC", (category,))
            else:
                cursor.execute("SELECT id, content, category, importance, embedding_json, metadata_json, created_at FROM memories ORDER BY id DESC")
                
            rows = cursor.fetchall()
            return [
                {
                    "id": r[0],
                    "content": r[1],
                    "category": r[2],
                    "importance": r[3],
                    "embedding": json.loads(r[4]) if r[4] else [],
                    "metadata": json.loads(r[5]) if r[5] else {},
                    "created_at": r[6]
                }
                for r in rows
            ]

    def forget(self, memory_id: int) -> bool:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM memories WHERE id = ?", (memory_id,))
            conn.commit()
            return cursor.rowcount > 0

    def clear_all(self):
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM memories")
            conn.commit()

long_term_memory = LongTermMemory()
