"""
Automated Test for Research Agent (Phase 2 Priority #3).
Tests research topic querying, cache hit on repeat research, and report generation.
"""

import sys
import os
import asyncio

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "src")))

from agents.research_agent import ResearchAgent

async def test_research_agent():
    agent = ResearchAgent()
    
    # 1. Execute research task
    res1 = await agent.execute_action("research", {"topic": "AI Operating System Architecture"})
    assert res1["status"] == "success"
    assert "report" in res1
    assert res1["source"] in ["llm", "cache"]

    # 2. Re-execute same research task to test Cache Layer hit
    res2 = await agent.execute_action("research", {"topic": "AI Operating System Architecture"})
    assert res2["status"] == "success"
    assert res2["source"] == "cache"

    print("[OK] Test Passed: ResearchAgent topic research, summary, and CacheLayer hit verified.")

if __name__ == "__main__":
    asyncio.run(test_research_agent())
