"""
BrowserAgent - Cognitive Web Browser Automation (Phase 2 Priority #1).
Reuses DOM perception & Playwright engine from agent_bot/agent_browser.py.
Enforces explicit human approval for form submissions, publishing, and destructive actions.
"""

import json
import time
import asyncio
import logging
from typing import Dict, Any, List, Optional
from playwright.async_api import async_playwright

from ..core.event_bus import bus
from ..core.plugin_manager import BasePlugin, plugin_manager
from ..providers.capability_selector import capability_selector

log = logging.getLogger("browser_agent")

DESTRUCTIVE_KEYWORDS = ["submit", "publish", "delete", "remove", "buy", "pay", "send", "confirm"]

class BrowserAgent(BasePlugin):
    def __init__(self, session_id: str = "default"):
        self.session_id = session_id
        self.history: List[Dict[str, Any]] = []

    @property
    def plugin_name(self) -> str:
        return "browser"

    @property
    def description(self) -> str:
        return "Cognitive browser automation agent powered by Playwright and local LLM perception."

    async def initialize(self) -> bool:
        log.info("[BrowserAgent] Initialized.")
        return True

    def parse_perception(self, raw_dom_elements: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Filter and format DOM elements for LLM perception."""
        parsed = []
        for el in raw_dom_elements:
            role = el.get("role", "element")
            text = el.get("text", "").strip()[:50]
            el_type = el.get("type", "")
            if text or role in ["button", "input", "a"]:
                parsed.append({"role": role, "text": text, "type": el_type})
        return parsed

    def requires_human_approval(self, action: str, target: str) -> bool:
        """Check if action is destructive or involves form submission/publishing."""
        text_check = f"{action} {target}".lower()
        for kw in DESTRUCTIVE_KEYWORDS:
            if kw in text_check:
                return True
        return False

    async def decide_action(self, goal: str, dom_summary: str) -> Dict[str, Any]:
        """Ask Capability Selector (LLM) for next cognitive web action."""
        prompt = (
            f"GOAL: {goal}\n\n"
            f"DOM ELEMENTS: {dom_summary}\n\n"
            f"RECENT HISTORY: {self.history[-3:]}\n\n"
            "Return JSON action: {'action': 'click|type|wait|submit|done|error', 'target': 'text', 'value': 'optional'}"
        )
        
        system_prompt = (
            "You are a Browser Automation Agent. Respond strictly in JSON format. "
            "Prioritize visible text on buttons and input fields."
        )

        res = capability_selector.generate(
            prompt=prompt,
            capability="reasoning",
            system_prompt=system_prompt
        )

        try:
            return json.loads(res)
        except Exception:
            return {"action": "wait", "reason": "Failed to parse LLM JSON", "raw": res}

    async def execute_action(self, action_name: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Plugin entrypoint."""
        goal = payload.get("goal", "Navigate")
        url = payload.get("url")

        log.info(f"[BrowserAgent] Mission: {goal} | URL: {url}")
        
        # Check safety before execution
        if self.requires_human_approval(action_name, goal):
            log.warning(f"[BrowserAgent] Safety Gate Triggered! Action '{action_name}' on '{goal}' requires human approval.")
            return {
                "status": "approval_required",
                "message": f"Action '{action_name}' on '{goal}' requires explicit user confirmation.",
                "payload": payload
            }

        return {"status": "success", "session": self.session_id, "goal": goal}

# Register plugin instance
browser_agent_instance = BrowserAgent()
plugin_manager.register_plugin(browser_agent_instance)
