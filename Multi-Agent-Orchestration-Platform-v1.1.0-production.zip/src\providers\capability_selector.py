"""
Capability-Based Dynamic Model Selector.
Selects local model based on required task capability:
- reasoning / planning -> Priority: Bonsai 27B 1-bit > Qwen 3 > Qwen 2.5 1.5B
- coding               -> Qwen Code / Qwen 2.5 1.5B
- summarization / OCR  -> Qwen 2.5 0.5B / ultra-light
"""

import httpx
import logging
from typing import Dict, Any, List, Optional

log = logging.getLogger("capability_selector")

# Capability mapping
CAPABILITY_MAP = {
    "reasoning": ["bonsai", "qwen3", "qwen2.5:1.5b", "qwen2.5:0.5b"],
    "planning":  ["bonsai", "qwen3", "qwen2.5:1.5b"],
    "coding":    ["qwen-code", "qwen2.5:1.5b", "bonsai"],
    "summarization": ["qwen2.5:0.5b", "qwen2.5:1.5b"],
    "ocr":       ["qwen2.5:0.5b", "qwen2.5:1.5b"],
    "general":   ["qwen2.5:1.5b", "qwen2.5:0.5b"]
}

class CapabilityModelSelector:
    def __init__(self, ollama_url: str = "http://localhost:11434"):
        self.ollama_url = ollama_url.rstrip("/")
        self.available_models: List[str] = []

    def probe_models(self) -> List[str]:
        try:
            r = httpx.get(f"{self.ollama_url}/api/tags", timeout=5)
            if r.status_code == 200:
                self.available_models = [m.get("name", "") for m in r.json().get("models", [])]
                return self.available_models
        except Exception as e:
            log.warning(f"[CapabilitySelector] Probe failed: {e}")
        return []

    def select_model_for_capability(self, capability: str = "general") -> str:
        """Select best available model matching requested capability."""
        installed = self.probe_models()
        candidates = CAPABILITY_MAP.get(capability.lower(), CAPABILITY_MAP["general"])

        for candidate_pattern in candidates:
            for m in installed:
                if candidate_pattern.lower() in m.lower():
                    log.info(f"[CapabilitySelector] Capability '{capability}' -> Selected model '{m}'")
                    return m

        fallback = installed[0] if installed else "qwen2.5:1.5b"
        log.info(f"[CapabilitySelector] Capability '{capability}' -> Fallback model '{fallback}'")
        return fallback

    def generate(self, prompt: str, capability: str = "general", system_prompt: str = None) -> str:
        model = self.select_model_for_capability(capability)
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})

        payload = {"model": model, "messages": messages, "stream": False}

        try:
            r = httpx.post(f"{self.ollama_url}/api/chat", json=payload, timeout=60)
            if r.status_code == 200:
                return r.json().get("message", {}).get("content", "").strip()
            return f"Error: Status {r.status_code}"
        except Exception as e:
            return f"Error: {e}"

# Singleton
capability_selector = CapabilityModelSelector()
