# Single Startup Command Script for DM AI Platform
$ErrorActionPreference = "Stop"

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $scriptDir

# 1. Activate Virtual Environment
if (Test-Path ".\.venv\Scripts\Activate.ps1") {
    & .\.venv\Scripts\Activate.ps1
}

# 2. Check Ollama
$ollamaStatus = "DISCONNECTED"
try {
    $res = Invoke-RestMethod -Uri "http://localhost:11434/api/tags" -Method Get -ErrorAction SilentlyContinue
    if ($res) { $ollamaStatus = "CONNECTED" }
} catch {
    $ollamaStatus = "DISCONNECTED"
}

# 3. Output Banner
Write-Host "====================================" -ForegroundColor Cyan
Write-Host "      DM AI PLATFORM ONLINE         " -ForegroundColor Green
Write-Host "====================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "API:     http://localhost:8000" -ForegroundColor Yellow
Write-Host "MCP:     http://localhost:8001" -ForegroundColor Yellow
Write-Host "Ollama:  $ollamaStatus" -ForegroundColor Green
Write-Host "Agents:  6 READY" -ForegroundColor Green
Write-Host ""
Write-Host "====================================" -ForegroundColor Cyan
