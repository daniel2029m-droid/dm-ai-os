import time
from typing import List, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, Security
from .schemas import (
    HealthResponse,
    SystemStatusResponse,
    AgentRunRequest,
    AgentRunResponse,
    WorkflowRunRequest,
    WorkflowRunResponse
)
from .auth import verify_api_key

from src.core.plugin_manager import plugin_manager
from src.providers.capability_selector import capability_selector
from src.storage.storage_layer import storage
from src.core.context_manager import context_mgr
from src.core.dag_engine import TaskDAG

# Import agents to ensure registration
import src.agents.browser_agent
import src.agents.computer_agent
import src.agents.research_agent
import src.agents.facebook_agent
import src.agents.university_agent
import src.agents.media_agent

router = APIRouter()

@router.get("/health", response_model=HealthResponse)
async def get_health():
    return HealthResponse(status="ONLINE", version="v1.0.0-production")

@router.get("/system/status", response_model=SystemStatusResponse, dependencies=[Depends(verify_api_key)])
async def get_system_status():
    await plugin_manager.initialize_all()
    plugins = plugin_manager.list_plugins()
    models = capability_selector.probe_models()
    
    return SystemStatusResponse(
        system_status="ONLINE",
        agents=plugins,
        models={"ollama_models": models},
        cache={"directory": str(storage.cache.cache_dir)},
        database={"path": str(storage.sqlite_db.db_path)},
        active_tasks=len(context_mgr.active_tasks)
    )

@router.get("/agents", dependencies=[Depends(verify_api_key)])
async def list_agents():
    await plugin_manager.initialize_all()
    return plugin_manager.list_plugins()

@router.post("/agent/run", response_model=AgentRunResponse, dependencies=[Depends(verify_api_key)])
async def run_agent(req: AgentRunRequest):
    await plugin_manager.initialize_all()
    t0 = time.perf_counter()
    
    agent_name = req.agent.lower()
    if agent_name not in plugin_manager.plugins:
        raise HTTPException(status_code=404, detail=f"Agent '{agent_name}' not found")
        
    action_name = req.params.get("action", agent_name if agent_name != "browser" else "navigate")
    payload = {"topic": req.task, "prompt": req.task, "concept": req.task, "command": req.task, "goal": req.task}
    payload.update(req.params)
    
    res = await plugin_manager.invoke(agent_name, action_name, payload)
    elapsed = round((time.perf_counter() - t0) * 1000, 2)
    
    return AgentRunResponse(
        status="SUCCESS" if res.get("status") != "FAILED" else "FAILED",
        agent=agent_name,
        result=res,
        execution_time_ms=elapsed
    )

@router.post("/workflow/run", response_model=WorkflowRunResponse, dependencies=[Depends(verify_api_key)])
async def run_workflow(req: WorkflowRunRequest):
    await plugin_manager.initialize_all()
    t0 = time.perf_counter()
    
    model_assigned = capability_selector.select_model_for_capability("planning")
    
    dag = TaskDAG("api_workflow_dag")
    
    async def step_research():
        return await plugin_manager.invoke("research", "research", {"topic": req.goal})
        
    async def step_content():
        return await plugin_manager.invoke("facebook", "create_post", {"topic": req.goal})
        
    dag.add_node("research", step_research)
    dag.add_node("content", step_content, dependencies=["research"])
    
    dag_res = await dag.execute_parallel()
    elapsed = round(time.perf_counter() - t0, 2)
    
    return WorkflowRunResponse(
        status="SUCCESS",
        goal=req.goal,
        model_assigned=model_assigned,
        result=dag_res["node_results"],
        execution_time_sec=elapsed
    )
